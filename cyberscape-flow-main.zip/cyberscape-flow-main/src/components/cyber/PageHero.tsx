import bg from "@/assets/page-hero-astronaut.jpg";

interface Props {
  eyebrow: string;
  title: string;
  subtitle?: string;
  children?: React.ReactNode;
}

export function PageHero({ eyebrow, title, subtitle, children }: Props) {
  return (
    <section className="relative z-10 px-6 lg:px-10 mt-8">
      <div className="glass-panel rounded-2xl overflow-hidden relative scanline min-h-[340px]">
        <img
          src={bg}
          alt=""
          width={1920}
          height={800}
          className="absolute inset-0 w-full h-full object-cover opacity-60"
        />
        <div className="absolute inset-0" style={{ background: "linear-gradient(90deg, oklch(0.13 0.04 280 / 0.92) 0%, oklch(0.13 0.04 280 / 0.55) 60%, oklch(0.13 0.04 280 / 0.2) 100%)" }} />
        <div className="absolute inset-0 grid-bg opacity-30" />
        <div className="relative z-10 p-10 lg:p-16 max-w-3xl">
          <p className="text-xs font-mono uppercase tracking-[0.3em] neon-text-cyan mb-4">{eyebrow}</p>
          <h1 className="font-display text-5xl lg:text-7xl font-black tracking-wider neon-text-purple leading-none">
            {title}
          </h1>
          {subtitle && (
            <p className="mt-6 text-base text-muted-foreground max-w-xl leading-relaxed">{subtitle}</p>
          )}
          {children && <div className="mt-8">{children}</div>}
        </div>
      </div>
    </section>
  );
}
