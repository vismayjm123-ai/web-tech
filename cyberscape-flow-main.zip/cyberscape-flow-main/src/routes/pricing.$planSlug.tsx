import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Check } from "lucide-react";
import { SiteNav } from "@/components/cyber/SiteNav";
import { SiteFooter } from "@/components/cyber/SiteFooter";
import { plans } from "@/lib/cyber-data";

export const Route = createFileRoute("/pricing/$planSlug")({
  loader: ({ params }) => {
    const plan = plans.find((p) => p.slug === params.planSlug);
    if (!plan) throw notFound();
    return { plan };
  },
  component: PlanDetailPage,
  notFoundComponent: () => (
    <div className="min-h-screen flex items-center justify-center">
      <div className="glass-panel rounded-2xl p-10 text-center">
        <h1 className="font-display text-3xl neon-text-purple mb-4">PLAN NOT FOUND</h1>
        <Link to="/pricing" className="text-xs font-mono uppercase tracking-widest neon-text-cyan">← Back to pricing</Link>
      </div>
    </div>
  ),
  errorComponent: ({ error }) => (
    <div className="min-h-screen flex items-center justify-center text-foreground"><p>{error.message}</p></div>
  ),
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.plan.name ?? "Plan"} Plan — CyberScape` },
      { name: "description", content: loaderData?.plan.tagline ?? "" },
    ],
  }),
});

function PlanDetailPage() {
  const { plan } = Route.useLoaderData();

  return (
    <div className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-40 pointer-events-none" />
      <SiteNav />

      <section className="relative z-10 px-6 lg:px-10 mt-8">
        <Link to="/pricing" className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest neon-text-cyan mb-4">
          <ArrowLeft className="size-3.5" /> All plans
        </Link>
        <div className="glass-panel rounded-2xl p-10 lg:p-14" style={{ borderColor: plan.color, boxShadow: `0 0 40px color-mix(in oklab, ${plan.color} 30%, transparent)` }}>
          <span className="text-[10px] font-mono uppercase tracking-widest px-3 py-1 rounded-md glass-panel inline-block mb-4" style={{ color: plan.color, borderColor: plan.color }}>
            {plan.tagline}
          </span>
          <h1 className="font-display text-5xl lg:text-7xl font-black tracking-wider leading-none" style={{ color: plan.color }}>
            {plan.name.toUpperCase()}
          </h1>
          <p className="mt-6 text-muted-foreground leading-relaxed max-w-2xl">{plan.longDesc}</p>

          <div className="mt-8 grid sm:grid-cols-2 gap-4 max-w-xl">
            <div className="glass-panel rounded-xl p-5">
              <div className="text-xs font-mono uppercase tracking-widest text-muted-foreground">Monthly</div>
              <div className="font-display text-4xl font-black mt-1" style={{ color: plan.color }}>${plan.monthly}<span className="text-sm text-muted-foreground font-mono"> /mo</span></div>
            </div>
            <div className="glass-panel rounded-xl p-5">
              <div className="text-xs font-mono uppercase tracking-widest text-muted-foreground">Annual <span className="neon-text-cyan">−15%</span></div>
              <div className="font-display text-4xl font-black mt-1" style={{ color: plan.color }}>${plan.annual}<span className="text-sm text-muted-foreground font-mono"> /mo</span></div>
            </div>
          </div>

          <div className="mt-8 flex flex-wrap gap-4">
            <Link to="/contact" className="rounded-lg px-6 py-3 text-xs font-mono uppercase tracking-widest text-primary-foreground flex items-center gap-2 animate-pulse-glow" style={{ background: "var(--gradient-purple)" }}>
              Choose {plan.name} <ArrowRight className="size-4" />
            </Link>
            <Link to="/pricing" className="glass-panel glow-border-cyan rounded-lg px-6 py-3 text-xs font-mono uppercase tracking-widest neon-text-cyan">
              Compare plans
            </Link>
          </div>
        </div>
      </section>

      <section className="relative z-10 px-6 lg:px-10 mt-6 mb-10 grid lg:grid-cols-2 gap-5">
        <div className="glass-panel rounded-2xl p-8">
          <h2 className="font-display text-lg font-bold tracking-widest neon-text-cyan mb-6">WHAT'S INCLUDED</h2>
          <ul className="space-y-3">
            {plan.features.map((f: string) => (
              <li key={f} className="flex items-start gap-3 text-sm text-muted-foreground">
                <Check className="size-5 shrink-0 mt-0.5" style={{ color: plan.color }} />
                <span>{f}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="glass-panel rounded-2xl p-8">
          <h2 className="font-display text-lg font-bold tracking-widest neon-text-pink mb-6">ALSO INCLUDES</h2>
          <ul className="space-y-3">
            {plan.includes.map((f: string) => (
              <li key={f} className="flex items-start gap-3 text-sm text-muted-foreground">
                <Check className="size-5 shrink-0 mt-0.5 neon-text-pink" />
                <span>{f}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
