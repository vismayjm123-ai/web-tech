import { Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";

export function SiteFooter() {
  return (
    <footer className="relative z-10 px-6 lg:px-10 pb-10 pt-6">
      <div className="glass-panel rounded-2xl p-6 flex flex-wrap items-center justify-between gap-4">
        <div className="font-display text-lg font-black neon-text-purple tracking-wider">CYBERSCAPE</div>
        <p className="text-xs font-mono uppercase tracking-widest text-muted-foreground">
          © 2026 — Engineered for the future
        </p>
        <Link to="/contact" className="text-xs font-mono uppercase tracking-widest neon-text-cyan flex items-center gap-2">
          Enter terminal <ArrowUpRight className="size-3.5" />
        </Link>
      </div>
    </footer>
  );
}
