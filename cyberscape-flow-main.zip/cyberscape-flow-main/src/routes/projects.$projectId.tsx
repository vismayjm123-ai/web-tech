import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Check } from "lucide-react";
import { SiteNav } from "@/components/cyber/SiteNav";
import { SiteFooter } from "@/components/cyber/SiteFooter";
import { projects } from "@/lib/cyber-data";

export const Route = createFileRoute("/projects/$projectId")({
  loader: ({ params }) => {
    const project = projects.find((p) => p.slug === params.projectId);
    if (!project) throw notFound();
    return { project };
  },
  component: ProjectDetailPage,
  notFoundComponent: () => (
    <div className="min-h-screen flex items-center justify-center">
      <div className="glass-panel rounded-2xl p-10 text-center">
        <h1 className="font-display text-3xl neon-text-purple mb-4">PROJECT NOT FOUND</h1>
        <Link to="/projects" className="text-xs font-mono uppercase tracking-widest neon-text-cyan">← Back to projects</Link>
      </div>
    </div>
  ),
  errorComponent: ({ error }) => (
    <div className="min-h-screen flex items-center justify-center text-foreground">
      <p>{error.message}</p>
    </div>
  ),
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.project.title ?? "Project"} — CyberScape` },
      { name: "description", content: loaderData?.project.desc ?? "" },
    ],
  }),
});

function ProjectDetailPage() {
  const { project } = Route.useLoaderData();
  const Icon = project.icon;

  return (
    <div className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-40 pointer-events-none" />
      <SiteNav />

      <section className="relative z-10 px-6 lg:px-10 mt-8">
        <Link to="/projects" className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest neon-text-cyan mb-4">
          <ArrowLeft className="size-3.5" /> All projects
        </Link>
        <div className="glass-panel rounded-2xl overflow-hidden grid lg:grid-cols-2 gap-0">
          <div className="p-10 lg:p-14 flex flex-col justify-center">
            <span className="text-[10px] font-mono uppercase tracking-widest px-3 py-1 rounded-md glass-panel neon-text-cyan border border-[var(--neon-cyan)]/30 self-start mb-4">
              {project.tag}
            </span>
            <h1 className="font-display text-5xl lg:text-7xl font-black tracking-wider neon-text-purple leading-none">
              {project.title.toUpperCase()}
            </h1>
            <p className="mt-6 text-muted-foreground leading-relaxed max-w-md">{project.longDesc}</p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link to="/contact" className="rounded-lg px-6 py-3 text-xs font-mono uppercase tracking-widest text-primary-foreground flex items-center gap-2 animate-pulse-glow" style={{ background: "var(--gradient-purple)" }}>
                Request demo <ArrowRight className="size-4" />
              </Link>
              <Link to="/pricing" className="glass-panel glow-border-cyan rounded-lg px-6 py-3 text-xs font-mono uppercase tracking-widest neon-text-cyan">
                See pricing
              </Link>
            </div>
          </div>
          <div className="relative min-h-[360px] flex items-center justify-center scanline" style={{ background: "var(--gradient-card)" }}>
            <div className="absolute inset-0 grid-bg opacity-40" />
            <Icon className="size-48 neon-text-purple animate-float relative z-10" />
          </div>
        </div>
      </section>

      <section className="relative z-10 px-6 lg:px-10 mt-6 grid lg:grid-cols-3 gap-5">
        {project.stats.map((s: { label: string; value: string }, i: number) => (
          <div key={s.label} className="glass-panel rounded-2xl p-6 text-center">
            <div className={`font-display text-4xl font-bold ${i === 0 ? "neon-text-purple" : i === 1 ? "neon-text-cyan" : "neon-text-pink"}`}>{s.value}</div>
            <div className="text-xs font-mono uppercase tracking-widest text-muted-foreground mt-2">{s.label}</div>
          </div>
        ))}
      </section>

      <section className="relative z-10 px-6 lg:px-10 mt-6 grid lg:grid-cols-2 gap-5">
        <div className="glass-panel rounded-2xl p-8">
          <h2 className="font-display text-lg font-bold tracking-widest neon-text-cyan mb-6">CORE FEATURES</h2>
          <ul className="space-y-3">
            {project.features.map((f: string) => (
              <li key={f} className="flex items-start gap-3 text-sm text-muted-foreground">
                <Check className="size-5 neon-text-purple shrink-0 mt-0.5" />
                <span>{f}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="glass-panel rounded-2xl p-8 flex flex-col justify-center items-start">
          <h2 className="font-display text-2xl font-bold tracking-widest neon-text-pink mb-3">DEPLOY {project.title.toUpperCase()}</h2>
          <p className="text-sm text-muted-foreground mb-6 max-w-md">
            Plug {project.title} into your stack and unlock the next-generation operations layer of the cyberscape.
          </p>
          <Link to="/contact" className="rounded-lg px-6 py-3 text-xs font-mono uppercase tracking-widest text-primary-foreground flex items-center gap-2 animate-pulse-glow" style={{ background: "var(--gradient-purple)" }}>
            Start your project <ArrowRight className="size-4" />
          </Link>
        </div>
      </section>

      <div className="mt-10" />
      <SiteFooter />
    </div>
  );
}
