import {
  Shield, Cloud, Brain, Code2, Glasses, Network, CircuitBoard, Cpu,
  Atom, Wifi, Link as LinkIcon, type LucideIcon,
} from "lucide-react";

export interface Service {
  slug: string;
  icon: LucideIcon;
  title: string;
  desc: string;
  longDesc: string;
  color: string;
  features: string[];
  stats: { label: string; value: string }[];
}

export const services: Service[] = [
  {
    slug: "cyber-security", icon: Shield, title: "Cyber Security",
    desc: "Advanced protection for your digital assets and infrastructure.",
    longDesc: "A zero-trust security fabric that blends adaptive threat intelligence, behavioural analytics, and autonomous response to keep every byte of your cyberscape under constant watch.",
    color: "var(--neon-purple)",
    features: ["Zero-trust network access", "AI-driven threat hunting", "Continuous penetration testing", "24/7 SOC monitoring", "Encrypted vault storage"],
    stats: [{ label: "Threats blocked", value: "98K+" }, { label: "Avg response", value: "8 min" }, { label: "Uptime SLA", value: "99.99%" }],
  },
  {
    slug: "cloud-infrastructure", icon: Cloud, title: "Cloud Infrastructure",
    desc: "Scalable, secure, and reliable cloud solutions for businesses.",
    longDesc: "Globally distributed compute, storage, and networking primitives that scale from a single neon node to a planet-spanning mesh — without ever dropping a packet.",
    color: "var(--neon-cyan)",
    features: ["Multi-region deployments", "Auto-scaling clusters", "Edge-native runtime", "Cost-optimized storage tiers", "Disaster recovery automation"],
    stats: [{ label: "Regions", value: "42" }, { label: "Avg RTT", value: "23ms" }, { label: "SLA", value: "99.999%" }],
  },
  {
    slug: "ai-solutions", icon: Brain, title: "AI Solutions Lab",
    desc: "Intelligent AI systems to automate and accelerate growth.",
    longDesc: "Train, deploy, and orchestrate frontier-grade models with a lab that handles everything from data pipelines to inference acceleration on bespoke neural runtimes.",
    color: "var(--neon-pink)",
    features: ["Custom LLM fine-tuning", "Vision & speech models", "Vector search infrastructure", "Realtime inference APIs", "MLOps lifecycle automation"],
    stats: [{ label: "Models shipped", value: "240+" }, { label: "Inference / sec", value: "1.2M" }, { label: "GPU clusters", value: "36" }],
  },
  {
    slug: "web-app-dev", icon: Code2, title: "Web & App Development",
    desc: "Futuristic websites, web apps and digital platforms.",
    longDesc: "Cinematic interfaces engineered with motion grammar, accessibility, and edge performance — built by a crew that treats every pixel like a HUD element.",
    color: "var(--neon-cyan)",
    features: ["Design-system led builds", "Edge-rendered apps", "Animation & motion systems", "Headless commerce", "Lighthouse 100 by default"],
    stats: [{ label: "Apps shipped", value: "180+" }, { label: "Avg LCP", value: "0.9s" }, { label: "A11y score", value: "100" }],
  },
  {
    slug: "immersive", icon: Glasses, title: "Immersive Technologies",
    desc: "AR/VR, metaverse spaces and next-gen experiences.",
    longDesc: "Spatial computing, holographic UIs, and persistent metaverse environments that turn flat experiences into walk-in worlds.",
    color: "var(--neon-purple)",
    features: ["WebXR experiences", "Spatial UI systems", "Persistent metaverse rooms", "Volumetric video", "Haptic + voice interaction"],
    stats: [{ label: "XR scenes", value: "60+" }, { label: "Avg FPS", value: "90" }, { label: "Devices", value: "All major" }],
  },
];

export interface Technology {
  slug: string;
  icon: LucideIcon;
  title: string;
  desc: string;
  longDesc: string;
  color: string;
  capabilities: string[];
  stats: { label: string; value: string }[];
}

export const technologies: Technology[] = [
  {
    slug: "ai-ml", icon: Brain, title: "AI & Machine Learning",
    desc: "Intelligent models for prediction, automation, and decision-making.",
    longDesc: "Frontier neural architectures, fine-tuned LLMs, and reinforcement systems wired into your data so every workflow learns and improves on its own.",
    color: "var(--neon-pink)",
    capabilities: ["Foundation model fine-tuning", "Multi-modal pipelines", "Realtime recommendation engines", "Autonomous agents"],
    stats: [{ label: "Models", value: "240+" }, { label: "Tokens / day", value: "9.4B" }, { label: "Accuracy", value: "98.6%" }],
  },
  {
    slug: "cyber-security", icon: Shield, title: "Cyber Security",
    desc: "Advanced threat detection, encryption, and zero-trust systems.",
    longDesc: "An adaptive defense mesh that combines zero-trust enforcement, AI threat hunting, and post-quantum encryption for end-to-end resilience.",
    color: "var(--neon-purple)",
    capabilities: ["Zero-trust enforcement", "Post-quantum encryption", "Behavioural anomaly detection", "Automated incident response"],
    stats: [{ label: "Threats blocked", value: "98K+" }, { label: "False positives", value: "<0.1%" }, { label: "MTTR", value: "8 min" }],
  },
  {
    slug: "cloud", icon: Cloud, title: "Cloud Computing",
    desc: "Scalable, distributed, high-performance cloud solutions.",
    longDesc: "Multi-cloud orchestration with edge-native runtimes, microsecond replication, and zero-downtime failover across 42 regions.",
    color: "var(--neon-cyan)",
    capabilities: ["Multi-cloud orchestration", "Serverless edge runtime", "Microsecond replication", "FinOps optimization"],
    stats: [{ label: "Regions", value: "42" }, { label: "Avg RTT", value: "23ms" }, { label: "SLA", value: "99.999%" }],
  },
  {
    slug: "blockchain", icon: LinkIcon, title: "Blockchain",
    desc: "Transparent, secure, and decentralized infrastructure.",
    longDesc: "Permissioned and public chain integration with smart-contract auditing, token engineering, and cross-chain bridges built for production.",
    color: "var(--neon-purple)",
    capabilities: ["Smart-contract auditing", "Token engineering", "Cross-chain bridges", "On-chain analytics"],
    stats: [{ label: "Contracts shipped", value: "320" }, { label: "TVL secured", value: "$1.4B" }, { label: "Chains", value: "12" }],
  },
  {
    slug: "quantum", icon: Atom, title: "Quantum Computing",
    desc: "Solving complex problems with next-gen quantum systems.",
    longDesc: "Hybrid quantum-classical pipelines for optimization, cryptography, and materials simulation — accessible through a unified neon SDK.",
    color: "var(--neon-cyan)",
    capabilities: ["Hybrid quantum-classical workloads", "Quantum-safe cryptography", "Optimization solvers", "Material simulation"],
    stats: [{ label: "Qubits", value: "1024" }, { label: "Coherence", value: "210µs" }, { label: "Backends", value: "5" }],
  },
  {
    slug: "edge", icon: Cpu, title: "Edge Computing",
    desc: "Real-time processing closer to the source of data.",
    longDesc: "Edge orchestration that pushes compute, AI inference, and stateful workloads to thousands of nodes within milliseconds of your users.",
    color: "var(--neon-pink)",
    capabilities: ["Edge inference runtime", "Stateful edge workloads", "Geo-fenced data residency", "5G integration"],
    stats: [{ label: "Edge nodes", value: "1,024" }, { label: "Avg latency", value: "12ms" }, { label: "Throughput", value: "8 Tbps" }],
  },
  {
    slug: "iot", icon: Wifi, title: "IoT Integration",
    desc: "Seamless connectivity and intelligence across devices.",
    longDesc: "Device-to-cloud telemetry, OTA updates, and digital twins for fleets of millions — secured by hardware-rooted identity.",
    color: "var(--neon-cyan)",
    capabilities: ["Device identity & attestation", "OTA firmware delivery", "Digital twins", "Realtime telemetry pipelines"],
    stats: [{ label: "Devices", value: "4.2M" }, { label: "Messages / sec", value: "850K" }, { label: "Uptime", value: "99.98%" }],
  },
  {
    slug: "ar-vr", icon: Glasses, title: "AR / VR Technology",
    desc: "Immersive experiences in virtual and augmented worlds.",
    longDesc: "Spatial computing stacks for headsets, glasses, and the open web — with photoreal rendering, hand tracking, and persistent worlds.",
    color: "var(--neon-purple)",
    capabilities: ["WebXR experiences", "Hand & eye tracking", "Photoreal rendering", "Persistent shared worlds"],
    stats: [{ label: "XR scenes", value: "60+" }, { label: "Avg FPS", value: "90" }, { label: "Headsets", value: "All major" }],
  },
];

export interface Project {
  slug: string;
  icon: LucideIcon;
  title: string;
  desc: string;
  longDesc: string;
  tag: string;
  features: string[];
  stats: { label: string; value: string }[];
}

export const projects: Project[] = [
  {
    slug: "neural-grid", icon: Network, title: "Neural Grid",
    desc: "AI-powered monitoring and analytics system.",
    longDesc: "Neural Grid is a distributed intelligence platform that monitors millions of signals in real time, surfaces anomalies before they escalate, and automates response across hybrid environments.",
    tag: "AI System",
    features: ["Real-time anomaly detection", "Federated model training", "Auto-scaling inference nodes", "Predictive incident routing"],
    stats: [{ label: "Signals/sec", value: "2.4M" }, { label: "Avg latency", value: "12ms" }, { label: "Uptime", value: "99.99%" }],
  },
  {
    slug: "phantom-shield", icon: Shield, title: "Phantom Shield",
    desc: "Advanced cybersecurity operations dashboard.",
    longDesc: "Phantom Shield is a unified SOC command center that fuses threat intel, endpoint telemetry, and identity signals into a single neon-lit war room.",
    tag: "Cyber Security",
    features: ["Zero-trust enforcement", "Threat intel fusion", "Live attack graph", "Automated containment playbooks"],
    stats: [{ label: "Threats blocked", value: "98K+" }, { label: "MTTR", value: "8 min" }, { label: "Endpoints", value: "120K" }],
  },
  {
    slug: "nova-cloud", icon: Cloud, title: "Nova Cloud",
    desc: "Next-gen distributed cloud infrastructure.",
    longDesc: "Nova Cloud delivers a global mesh of compute, storage, and networking primitives engineered for microsecond replication and zero-downtime failover.",
    tag: "Cloud Platform",
    features: ["Global anycast routing", "Microsecond replication", "Edge-native runtime", "Pay-per-millisecond billing"],
    stats: [{ label: "Regions", value: "42" }, { label: "Avg RTT", value: "23ms" }, { label: "SLA", value: "99.999%" }],
  },
  {
    slug: "vortex-ui", icon: CircuitBoard, title: "Vortex UI",
    desc: "Immersive futuristic frontend framework.",
    longDesc: "Vortex UI is a holographic component library and design system that lets product teams ship cinematic interfaces without sacrificing accessibility or performance.",
    tag: "Web Technology",
    features: ["120+ HUD components", "Built-in motion grammar", "Accessible by default", "Token-driven theming"],
    stats: [{ label: "Components", value: "120+" }, { label: "Bundle", value: "38kb" }, { label: "A11y score", value: "100" }],
  },
];

export interface Plan {
  slug: string;
  name: string;
  tagline: string;
  monthly: number;
  annual: number;
  color: string;
  highlight: boolean;
  longDesc: string;
  features: string[];
  includes: string[];
}

export const plans: Plan[] = [
  {
    slug: "recon", name: "Recon", tagline: "For solo operators",
    monthly: 29, annual: 24, color: "var(--neon-cyan)", highlight: false,
    longDesc: "A streamlined access tier for lone wolves who need pro-grade cyber tooling without the overhead of an enterprise stack.",
    features: ["1 active workspace", "5 cyber modules", "Standard threat shield", "Community support", "10K AI requests / mo"],
    includes: ["Recon dashboard", "Email alerting", "Public API access", "Single-user identity"],
  },
  {
    slug: "operator", name: "Operator", tagline: "For growing networks",
    monthly: 89, annual: 74, color: "var(--neon-purple)", highlight: true,
    longDesc: "The most-loved tier — full Phantom Shield, live network analytics, and 24/7 priority support to keep your operation always-on.",
    features: ["10 workspaces", "All cyber modules", "Phantom Shield included", "Priority support 24/7", "500K AI requests / mo", "Live network analytics"],
    includes: ["All Recon features", "Team identity & SSO", "Custom dashboards", "Webhook automations", "Audit log retention 1yr"],
  },
  {
    slug: "sovereign", name: "Sovereign", tagline: "For the entire cyberscape",
    monthly: 249, annual: 209, color: "var(--neon-pink)", highlight: false,
    longDesc: "Unlimited everything, dedicated cloud nodes, and on-call security ops — engineered for governments, mega-corps, and global networks.",
    features: ["Unlimited workspaces", "Custom AI deployment", "Dedicated cloud nodes", "On-call security ops", "Unlimited AI requests", "White-glove onboarding", "SLA 99.999%"],
    includes: ["All Operator features", "Dedicated success team", "Custom legal & compliance", "On-prem deployment option", "99.999% SLA"],
  },
];
