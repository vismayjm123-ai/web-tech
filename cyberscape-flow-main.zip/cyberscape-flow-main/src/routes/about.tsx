import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Cpu, Globe2, Shield, Zap } from "lucide-react";
import { SiteNav } from "@/components/cyber/SiteNav";
import { SiteFooter } from "@/components/cyber/SiteFooter";
import { PageHero } from "@/components/cyber/PageHero";

export const Route = createFileRoute("/about")({
  component: AboutPage,
  head: () => ({
    meta: [
      { title: "About — CyberScape" },
      { name: "description", content: "We build the digital command center of tomorrow — where AI, cyber, and cloud converge." },
    ],
  }),
});

const values = [
  { icon: Zap, title: "Velocity", desc: "We ship at the speed of light, with zero compromise on craft." },
  { icon: Shield, title: "Trust", desc: "Security is the substrate of everything we engineer." },
  { icon: Globe2, title: "Scale", desc: "Built for one operator or a planetary network." },
  { icon: Cpu, title: "Intelligence", desc: "AI is not a feature — it's the operating system." },
];

function AboutPage() {
  return (
    <div className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-40 pointer-events-none" />
      <SiteNav />
      <PageHero
        eyebrow="The mission"
        title="ABOUT"
        subtitle="CyberScape is a digital command center engineered for the future. We build the systems that power the next era of intelligent infrastructure."
      />

      <section className="relative z-10 px-6 lg:px-10 mt-6 grid lg:grid-cols-2 gap-5">
        <div className="glass-panel rounded-2xl p-8">
          <h2 className="font-display text-xl font-bold tracking-widest neon-text-purple mb-4">OUR STORY</h2>
          <p className="text-sm text-muted-foreground leading-relaxed mb-4">
            Founded by a collective of cyber-engineers, AI researchers, and futurists, CyberScape was born from a single conviction: tomorrow's businesses deserve interfaces and infrastructure that feel like science fiction — but ship today.
          </p>
          <p className="text-sm text-muted-foreground leading-relaxed">
            We design and operate intelligent systems for organizations that refuse to accept legacy as destiny.
          </p>
        </div>
        <div className="glass-panel rounded-2xl p-8">
          <h2 className="font-display text-xl font-bold tracking-widest neon-text-cyan mb-4">THE VISION</h2>
          <p className="text-sm text-muted-foreground leading-relaxed mb-4">
            Apple meets Blade Runner meets Iron Man's Jarvis — a living network where every signal is intelligent, every interface is cinematic, and every operator feels superhuman.
          </p>
          <p className="text-sm text-muted-foreground leading-relaxed">
            That's the cyberscape. And we're just getting started.
          </p>
        </div>
      </section>

      <section className="relative z-10 px-6 lg:px-10 mt-6 mb-10">
        <div className="glass-panel rounded-2xl p-8">
          <h2 className="font-display text-xl font-bold tracking-widest neon-text-pink mb-8">CORE VALUES</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {values.map((v) => (
              <div key={v.title} className="glass-panel rounded-xl p-6">
                <div className="size-12 rounded-lg glass-panel glow-border-purple flex items-center justify-center mb-4">
                  <v.icon className="size-6 neon-text-purple" />
                </div>
                <h3 className="font-display font-bold tracking-wider mb-2">{v.title.toUpperCase()}</h3>
                <p className="text-xs text-muted-foreground leading-relaxed">{v.desc}</p>
              </div>
            ))}
          </div>
          <div className="mt-8 flex flex-wrap gap-4">
            <Link to="/contact" className="rounded-lg px-6 py-3 text-xs font-mono uppercase tracking-widest text-primary-foreground flex items-center gap-2 animate-pulse-glow" style={{ background: "var(--gradient-purple)" }}>
              Join the network <ArrowRight className="size-4" />
            </Link>
            <Link to="/projects" className="glass-panel glow-border-cyan rounded-lg px-6 py-3 text-xs font-mono uppercase tracking-widest neon-text-cyan">
              See our work
            </Link>
          </div>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
