import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Check } from "lucide-react";
import { SiteNav } from "@/components/cyber/SiteNav";
import { SiteFooter } from "@/components/cyber/SiteFooter";
import { technologies } from "@/lib/cyber-data";

export const Route = createFileRoute("/technology/$techSlug")({
  loader: ({ params }) => {
    const tech = technologies.find((t) => t.slug === params.techSlug);
    if (!tech) throw notFound();
    return { tech };
  },
  component: TechDetailPage,
  notFoundComponent: () => (
    <div className="min-h-screen flex items-center justify-center">
      <div className="glass-panel rounded-2xl p-10 text-center">
        <h1 className="font-display text-3xl neon-text-purple mb-4">TECHNOLOGY NOT FOUND</h1>
        <Link to="/technology" className="text-xs font-mono uppercase tracking-widest neon-text-cyan">← Back to technology</Link>
      </div>
    </div>
  ),
  errorComponent: ({ error }) => (
    <div className="min-h-screen flex items-center justify-center text-foreground"><p>{error.message}</p></div>
  ),
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.tech.title ?? "Technology"} — CyberScape` },
      { name: "description", content: loaderData?.tech.desc ?? "" },
    ],
  }),
});

function TechDetailPage() {
  const { tech } = Route.useLoaderData();
  const Icon = tech.icon;

  return (
    <div className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-40 pointer-events-none" />
      <SiteNav />

      <section className="relative z-10 px-6 lg:px-10 mt-8">
        <Link to="/technology" className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest neon-text-cyan mb-4">
          <ArrowLeft className="size-3.5" /> All technologies
        </Link>
        <div className="glass-panel rounded-2xl overflow-hidden grid lg:grid-cols-2" style={{ borderColor: tech.color }}>
          <div className="p-10 lg:p-14 flex flex-col justify-center">
            <span className="text-[10px] font-mono uppercase tracking-widest px-3 py-1 rounded-md glass-panel self-start mb-4" style={{ color: tech.color, borderColor: tech.color }}>
              Core Technology
            </span>
            <h1 className="font-display text-5xl lg:text-6xl font-black tracking-wider leading-none" style={{ color: tech.color }}>
              {tech.title.toUpperCase()}
            </h1>
            <p className="mt-6 text-muted-foreground leading-relaxed max-w-md">{tech.longDesc}</p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link to="/contact" className="rounded-lg px-6 py-3 text-xs font-mono uppercase tracking-widest text-primary-foreground flex items-center gap-2 animate-pulse-glow" style={{ background: "var(--gradient-purple)" }}>
                Talk to engineers <ArrowRight className="size-4" />
              </Link>
              <Link to="/services" className="glass-panel glow-border-cyan rounded-lg px-6 py-3 text-xs font-mono uppercase tracking-widest neon-text-cyan">
                Related services
              </Link>
            </div>
          </div>
          <div className="relative min-h-[320px] flex items-center justify-center scanline" style={{ background: "var(--gradient-card)" }}>
            <div className="absolute inset-0 grid-bg opacity-40" />
            <Icon className="size-44 animate-float relative z-10" style={{ color: tech.color }} />
          </div>
        </div>
      </section>

      <section className="relative z-10 px-6 lg:px-10 mt-6 grid lg:grid-cols-3 gap-5">
        {tech.stats.map((s: { label: string; value: string }, i: number) => (
          <div key={s.label} className="glass-panel rounded-2xl p-6 text-center">
            <div className={`font-display text-4xl font-bold ${i === 0 ? "neon-text-purple" : i === 1 ? "neon-text-cyan" : "neon-text-pink"}`}>{s.value}</div>
            <div className="text-xs font-mono uppercase tracking-widest text-muted-foreground mt-2">{s.label}</div>
          </div>
        ))}
      </section>

      <section className="relative z-10 px-6 lg:px-10 mt-6 mb-10">
        <div className="glass-panel rounded-2xl p-8">
          <h2 className="font-display text-lg font-bold tracking-widest neon-text-cyan mb-6">CAPABILITIES</h2>
          <ul className="grid sm:grid-cols-2 gap-3">
            {tech.capabilities.map((c: string) => (
              <li key={c} className="flex items-start gap-3 text-sm text-muted-foreground">
                <Check className="size-5 shrink-0 mt-0.5" style={{ color: tech.color }} />
                <span>{c}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
