import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Check } from "lucide-react";
import { SiteNav } from "@/components/cyber/SiteNav";
import { SiteFooter } from "@/components/cyber/SiteFooter";
import { services } from "@/lib/cyber-data";

export const Route = createFileRoute("/services/$serviceSlug")({
  loader: ({ params }) => {
    const service = services.find((s) => s.slug === params.serviceSlug);
    if (!service) throw notFound();
    return { service };
  },
  component: ServiceDetailPage,
  notFoundComponent: () => (
    <div className="min-h-screen flex items-center justify-center">
      <div className="glass-panel rounded-2xl p-10 text-center">
        <h1 className="font-display text-3xl neon-text-purple mb-4">SERVICE NOT FOUND</h1>
        <Link to="/services" className="text-xs font-mono uppercase tracking-widest neon-text-cyan">← Back to services</Link>
      </div>
    </div>
  ),
  errorComponent: ({ error }) => (
    <div className="min-h-screen flex items-center justify-center text-foreground"><p>{error.message}</p></div>
  ),
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.service.title ?? "Service"} — CyberScape` },
      { name: "description", content: loaderData?.service.desc ?? "" },
    ],
  }),
});

function ServiceDetailPage() {
  const { service } = Route.useLoaderData();
  const Icon = service.icon;

  return (
    <div className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-40 pointer-events-none" />
      <SiteNav />

      <section className="relative z-10 px-6 lg:px-10 mt-8">
        <Link to="/services" className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest neon-text-cyan mb-4">
          <ArrowLeft className="size-3.5" /> All services
        </Link>
        <div className="glass-panel rounded-2xl overflow-hidden grid lg:grid-cols-2 gap-0" style={{ borderColor: service.color }}>
          <div className="p-10 lg:p-14 flex flex-col justify-center">
            <span className="text-[10px] font-mono uppercase tracking-widest px-3 py-1 rounded-md glass-panel self-start mb-4" style={{ color: service.color, borderColor: service.color }}>
              Service Module
            </span>
            <h1 className="font-display text-5xl lg:text-7xl font-black tracking-wider leading-none" style={{ color: service.color }}>
              {service.title.toUpperCase()}
            </h1>
            <p className="mt-6 text-muted-foreground leading-relaxed max-w-md">{service.longDesc}</p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link to="/contact" className="rounded-lg px-6 py-3 text-xs font-mono uppercase tracking-widest text-primary-foreground flex items-center gap-2 animate-pulse-glow" style={{ background: "var(--gradient-purple)" }}>
                Engage module <ArrowRight className="size-4" />
              </Link>
              <Link to="/pricing" className="glass-panel glow-border-cyan rounded-lg px-6 py-3 text-xs font-mono uppercase tracking-widest neon-text-cyan">
                See pricing
              </Link>
            </div>
          </div>
          <div className="relative min-h-[360px] flex items-center justify-center scanline" style={{ background: "var(--gradient-card)" }}>
            <div className="absolute inset-0 grid-bg opacity-40" />
            <Icon className="size-48 animate-float relative z-10" style={{ color: service.color }} />
          </div>
        </div>
      </section>

      <section className="relative z-10 px-6 lg:px-10 mt-6 grid lg:grid-cols-3 gap-5">
        {service.stats.map((s: { label: string; value: string }, i: number) => (
          <div key={s.label} className="glass-panel rounded-2xl p-6 text-center">
            <div className={`font-display text-4xl font-bold ${i === 0 ? "neon-text-purple" : i === 1 ? "neon-text-cyan" : "neon-text-pink"}`}>{s.value}</div>
            <div className="text-xs font-mono uppercase tracking-widest text-muted-foreground mt-2">{s.label}</div>
          </div>
        ))}
      </section>

      <section className="relative z-10 px-6 lg:px-10 mt-6 mb-10 grid lg:grid-cols-2 gap-5">
        <div className="glass-panel rounded-2xl p-8">
          <h2 className="font-display text-lg font-bold tracking-widest neon-text-cyan mb-6">CAPABILITIES</h2>
          <ul className="space-y-3">
            {service.features.map((f: string) => (
              <li key={f} className="flex items-start gap-3 text-sm text-muted-foreground">
                <Check className="size-5 shrink-0 mt-0.5" style={{ color: service.color }} />
                <span>{f}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="glass-panel rounded-2xl p-8 flex flex-col justify-center items-start">
          <h2 className="font-display text-2xl font-bold tracking-widest neon-text-pink mb-3">DEPLOY {service.title.toUpperCase()}</h2>
          <p className="text-sm text-muted-foreground mb-6 max-w-md">
            Bring {service.title} online inside your stack and let the CyberScape grid handle the rest.
          </p>
          <Link to="/contact" className="rounded-lg px-6 py-3 text-xs font-mono uppercase tracking-widest text-primary-foreground flex items-center gap-2 animate-pulse-glow" style={{ background: "var(--gradient-purple)" }}>
            Start deployment <ArrowRight className="size-4" />
          </Link>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
