import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { SiteNav } from "@/components/cyber/SiteNav";
import { SiteFooter } from "@/components/cyber/SiteFooter";
import { PageHero } from "@/components/cyber/PageHero";
import { projects } from "@/lib/cyber-data";

export const Route = createFileRoute("/projects")({
  component: ProjectsPage,
  head: () => ({
    meta: [
      { title: "Projects — CyberScape" },
      { name: "description", content: "Featured CyberScape projects: Neural Grid, Phantom Shield, Nova Cloud, Vortex UI." },
    ],
  }),
});

function ProjectsPage() {
  return (
    <div className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-40 pointer-events-none" />
      <SiteNav />
      <PageHero
        eyebrow="Live in the network"
        title="PROJECTS"
        subtitle="A curated grid of platforms, dashboards, and frameworks we've launched into the cyberscape."
      />
      <section className="relative z-10 px-6 lg:px-10 mt-6 mb-10">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
          {projects.map((p) => (
            <Link
              key={p.slug}
              to="/projects/$projectId"
              params={{ projectId: p.slug }}
              className="glass-panel rounded-2xl p-6 hover:scale-[1.03] transition-all group block"
            >
              <div className="h-36 rounded-lg mb-4 flex items-center justify-center relative overflow-hidden" style={{ background: "var(--gradient-card)" }}>
                <div className="absolute inset-0 grid-bg opacity-40" />
                <p.icon className="size-16 neon-text-purple animate-float relative z-10" />
              </div>
              <h3 className="font-display font-bold tracking-wider mb-2">{p.title.toUpperCase()}</h3>
              <p className="text-xs text-muted-foreground leading-relaxed mb-4">{p.desc}</p>
              <div className="flex items-center justify-between">
                <span className="inline-block text-[10px] font-mono uppercase tracking-widest px-3 py-1 rounded-md glass-panel neon-text-cyan border border-[var(--neon-cyan)]/30">
                  {p.tag}
                </span>
                <ArrowRight className="size-4 neon-text-pink group-hover:translate-x-1 transition-transform" />
              </div>
            </Link>
          ))}
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
