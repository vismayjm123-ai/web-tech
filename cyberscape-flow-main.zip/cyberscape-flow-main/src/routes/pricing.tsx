import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Check, ArrowRight } from "lucide-react";
import { SiteNav } from "@/components/cyber/SiteNav";
import { SiteFooter } from "@/components/cyber/SiteFooter";
import { PageHero } from "@/components/cyber/PageHero";
import { plans } from "@/lib/cyber-data";

export const Route = createFileRoute("/pricing")({
  component: PricingPage,
  head: () => ({
    meta: [
      { title: "Pricing — CyberScape" },
      { name: "description", content: "Choose your CyberScape plan: Recon, Operator, or Sovereign. Monthly or annual billing." },
    ],
  }),
});

function PricingPage() {
  const [annual, setAnnual] = useState(false);

  return (
    <div className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-40 pointer-events-none" />
      <SiteNav />
      <PageHero
        eyebrow="Tiered access protocols"
        title="PRICING"
        subtitle="Three plans calibrated for every operator — from lone wolves to global cyber sovereigns."
      />

      <section className="relative z-10 px-6 lg:px-10 mt-6 flex justify-center">
        <div className="glass-panel rounded-full p-1.5 inline-flex items-center gap-1 text-xs font-mono uppercase tracking-widest">
          <button
            onClick={() => setAnnual(false)}
            className={`px-5 py-2 rounded-full transition-all ${!annual ? "neon-text-purple" : "text-muted-foreground"}`}
            style={!annual ? { background: "var(--gradient-purple)", color: "oklch(0.1 0.02 280)" } : undefined}
          >
            Monthly
          </button>
          <button
            onClick={() => setAnnual(true)}
            className={`px-5 py-2 rounded-full transition-all ${annual ? "neon-text-purple" : "text-muted-foreground"}`}
            style={annual ? { background: "var(--gradient-purple)", color: "oklch(0.1 0.02 280)" } : undefined}
          >
            Annual <span className="ml-1 neon-text-cyan">−15%</span>
          </button>
        </div>
      </section>

      <section className="relative z-10 px-6 lg:px-10 mt-6 mb-10">
        <div className="grid md:grid-cols-3 gap-5">
          {plans.map((p) => (
            <div
              key={p.name}
              className="glass-panel rounded-2xl p-8 flex flex-col relative"
              style={{
                borderColor: p.color,
                boxShadow: p.highlight ? `0 0 40px color-mix(in oklab, ${p.color} 30%, transparent)` : undefined,
                transform: p.highlight ? "translateY(-8px)" : undefined,
              }}
            >
              {p.highlight && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full text-[10px] font-mono uppercase tracking-widest text-primary-foreground" style={{ background: "var(--gradient-purple)" }}>
                  Most popular
                </span>
              )}
              <h3 className="font-display text-2xl font-bold tracking-wider" style={{ color: p.color }}>
                {p.name.toUpperCase()}
              </h3>
              <p className="text-xs font-mono uppercase tracking-widest text-muted-foreground mt-1">{p.tagline}</p>
              <div className="mt-6 flex items-baseline gap-2">
                <span className="font-display text-5xl font-black" style={{ color: p.color }}>
                  ${annual ? p.annual : p.monthly}
                </span>
                <span className="text-xs font-mono uppercase tracking-widest text-muted-foreground">/ mo</span>
              </div>
              {annual && (
                <p className="text-[10px] font-mono uppercase tracking-widest neon-text-cyan mt-1">
                  Billed ${p.annual * 12} annually
                </p>
              )}
              <ul className="mt-6 space-y-3 flex-1">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-3 text-sm text-muted-foreground">
                    <Check className="size-4 shrink-0 mt-0.5" style={{ color: p.color }} />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
              <Link
                to="/pricing/$planSlug"
                params={{ planSlug: p.slug }}
                className="mt-8 rounded-lg py-3 text-xs font-mono uppercase tracking-widest flex items-center justify-center gap-2 transition-all"
                style={p.highlight
                  ? { background: "var(--gradient-purple)", color: "oklch(0.1 0.02 280)" }
                  : { border: `1px solid ${p.color}`, color: p.color }}
              >
                View {p.name} <ArrowRight className="size-3.5" />
              </Link>
            </div>
          ))}
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
