import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, ChevronRight, Activity } from "lucide-react";
import { SiteNav } from "@/components/cyber/SiteNav";
import { SiteFooter } from "@/components/cyber/SiteFooter";
import { PageHero } from "@/components/cyber/PageHero";
import { services } from "@/lib/cyber-data";

export const Route = createFileRoute("/services")({
  component: ServicesPage,
  head: () => ({
    meta: [
      { title: "Services — CyberScape" },
      { name: "description", content: "Explore CyberScape's core services: cyber security, cloud, AI, web development, and immersive tech." },
    ],
  }),
});

function ServicesPage() {
  return (
    <div className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-40 pointer-events-none" />
      <div className="absolute inset-0 scanline pointer-events-none opacity-30" />
      <SiteNav />
      <PageHero
        eyebrow="Operational Modules / HUD"
        title="SERVICES"
        subtitle="Five interconnected service grids powering the CyberScape ecosystem — each engineered to scale your operations into the next era."
      />

      {/* HUD status bar */}
      <section className="relative z-10 px-6 lg:px-10 mt-4">
        <div className="glass-panel rounded-xl px-5 py-3 flex flex-wrap items-center justify-between gap-3 text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
          <div className="flex items-center gap-2 neon-text-cyan">
            <Activity className="size-3.5 animate-pulse" /> Modules online · {services.length} / {services.length}
          </div>
          <div>Sector: <span className="neon-text-purple">CyberScape-01</span></div>
          <div>Latency: <span className="neon-text-cyan">12ms</span></div>
          <div>Threat level: <span className="neon-text-pink">NOMINAL</span></div>
        </div>
      </section>

      <section className="relative z-10 px-6 lg:px-10 mt-6 mb-10">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {services.map((s, i) => (
            <Link
              key={s.slug}
              to="/services/$serviceSlug"
              params={{ serviceSlug: s.slug }}
              className="glass-panel rounded-2xl p-7 hover:scale-[1.02] transition-all group relative overflow-hidden block"
              style={{ borderColor: s.color }}
            >
              <span className="absolute top-3 right-4 text-[10px] font-mono tracking-widest text-muted-foreground">
                MOD/0{i + 1}
              </span>
              <div className="size-14 rounded-xl flex items-center justify-center mb-5"
                style={{ background: `color-mix(in oklab, ${s.color} 15%, transparent)`, boxShadow: `0 0 24px color-mix(in oklab, ${s.color} 35%, transparent)` }}>
                <s.icon className="size-7" style={{ color: s.color }} />
              </div>
              <h3 className="font-display text-lg font-bold tracking-wider mb-3" style={{ color: s.color }}>
                {s.title.toUpperCase()}
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed mb-6">{s.desc}</p>
              <div className="flex items-center justify-between text-xs font-mono uppercase tracking-widest" style={{ color: s.color }}>
                <span className="inline-flex items-center gap-2">Open module <ArrowRight className="size-3.5 group-hover:translate-x-1 transition-transform" /></span>
                <ChevronRight className="size-4 opacity-60" />
              </div>
            </Link>
          ))}
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
