import { Link } from "@tanstack/react-router";
import { ExternalLink, Zap } from "lucide-react";

function OpenInNewTabButton() {
  const handleClick = () => {
    if (typeof window !== "undefined") {
      window.open(window.location.href, "_blank", "noopener,noreferrer");
    }
  };
  return (
    <button
      type="button"
      onClick={handleClick}
      title="Open preview in new tab"
      className="glass-panel rounded-lg px-3 py-2.5 text-xs font-mono uppercase tracking-widest text-[var(--neon-cyan)] hover:scale-105 transition-transform flex items-center gap-2 shrink-0"
    >
      <ExternalLink className="size-3.5" />
      <span className="hidden lg:inline">New Tab</span>
    </button>
  );
}

const items = [
  { label: "Home", to: "/" },
  { label: "Services", to: "/services" },
  { label: "Technology", to: "/technology" },
  { label: "Projects", to: "/projects" },
  { label: "Pricing", to: "/pricing" },
  { label: "About", to: "/about" },
  { label: "Contact", to: "/contact" },
] as const;

export function SiteNav() {
  return (
    <header className="relative z-30 px-6 lg:px-10 pt-6">
      <nav className="glass-panel rounded-xl px-6 py-4 flex items-center justify-between gap-4">
        <Link to="/" className="font-display text-2xl font-black tracking-wider neon-text-purple shrink-0">
          CYBERSCAPE
        </Link>
        <ul className="hidden md:flex items-center gap-1 text-xs font-mono uppercase tracking-widest">
          {items.map((it) => (
            <li key={it.to}>
              <Link
                to={it.to}
                className="px-3 py-2 rounded-md transition-all text-muted-foreground hover:text-[var(--neon-cyan)]"
                activeProps={{ className: "px-3 py-2 rounded-md neon-text-purple border-b-2 border-[var(--neon-purple)]" }}
                activeOptions={{ exact: true }}
              >
                {it.label}
              </Link>
            </li>
          ))}
        </ul>
        <div className="flex items-center gap-2 shrink-0">
          <OpenInNewTabButton />
          <Link to="/contact" className="glass-panel glow-border-purple rounded-lg px-5 py-2.5 text-xs font-mono uppercase tracking-widest neon-text-purple flex items-center gap-2 hover:scale-105 transition-transform">
            Enter Network <Zap className="size-3.5" />
          </Link>
        </div>
      </nav>
    </header>
  );
}
