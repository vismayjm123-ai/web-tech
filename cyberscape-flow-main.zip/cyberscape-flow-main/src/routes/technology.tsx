import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteNav } from "@/components/cyber/SiteNav";
import { SiteFooter } from "@/components/cyber/SiteFooter";
import { PageHero } from "@/components/cyber/PageHero";
import { technologies } from "@/lib/cyber-data";

export const Route = createFileRoute("/technology")({
  component: TechnologyPage,
  head: () => ({
    meta: [
      { title: "Technology — CyberScape" },
      { name: "description", content: "Core technologies powering CyberScape: AI, blockchain, quantum, edge, IoT, and AR/VR." },
    ],
  }),
});

const stack = ["Python", "Rust", "Go", "Node.js", "React", "Next.js", "TensorFlow", "Docker", "Kubernetes", "PostgreSQL"];

function TechnologyPage() {
  return (
    <div className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-40 pointer-events-none" />
      <SiteNav />
      <PageHero
        eyebrow="Engineered for the future"
        title="TECHNOLOGY"
        subtitle="We build and utilize cutting-edge technologies to deliver powerful, secure, and scalable digital solutions."
      />

      <section className="relative z-10 px-6 lg:px-10 mt-6">
        <div className="glass-panel rounded-2xl p-8">
          <h2 className="font-display text-xl font-bold tracking-widest mb-2 neon-text-cyan">CORE TECHNOLOGIES</h2>
          <p className="text-xs text-muted-foreground font-mono uppercase tracking-wider mb-8">The foundation of our futuristic solutions</p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {technologies.map((t) => (
              <Link
                key={t.title}
                to="/technology/$techSlug"
                params={{ techSlug: t.slug }}
                className="glass-panel rounded-xl p-5 hover:scale-[1.03] transition-all block group"
              >
                <div className="size-12 rounded-lg glass-panel flex items-center justify-center mb-4 glow-border-cyan">
                  <t.icon className="size-6 neon-text-cyan" />
                </div>
                <h3 className="font-display text-sm font-bold tracking-wider mb-2 neon-text-cyan">{t.title.toUpperCase()}</h3>
                <p className="text-xs text-muted-foreground leading-relaxed">{t.desc}</p>
                <div className="mt-4 text-[10px] font-mono uppercase tracking-widest neon-text-pink opacity-0 group-hover:opacity-100 transition">Open →</div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="relative z-10 px-6 lg:px-10 mt-6 mb-10">
        <div className="glass-panel rounded-2xl p-8">
          <h2 className="font-display text-xl font-bold tracking-widest mb-2 neon-text-pink">TECH STACK</h2>
          <p className="text-xs text-muted-foreground font-mono uppercase tracking-wider mb-6">Our advanced development arsenal</p>
          <div className="flex flex-wrap gap-3">
            {stack.map((s) => (
              <span key={s} className="glass-panel rounded-lg px-4 py-2 text-xs font-mono uppercase tracking-widest neon-text-pink border border-[var(--neon-pink)]/30">
                {s}
              </span>
            ))}
          </div>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
