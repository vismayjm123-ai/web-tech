import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Shield, Cloud, Brain, Code2, Glasses, Server, Cpu, Activity,
  ArrowRight, Bot, Globe2, Network, CircuitBoard,
  Send, Radio, Zap,
} from "lucide-react";
import heroCity from "@/assets/hero-city.jpg";
import { SiteNav } from "@/components/cyber/SiteNav";
import { SiteFooter } from "@/components/cyber/SiteFooter";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "CyberScape — Next Generation Digital Platform" },
      { name: "description", content: "Advanced cyber services, cloud infrastructure, AI solutions, and futuristic digital experiences." },
    ],
  }),
});



const stats = [
  { icon: Server, value: "128+", label: "Servers Online", color: "purple" },
  { icon: Shield, value: "98,245+", label: "Threats Blocked", color: "cyan" },
  { icon: Cpu, value: "14M+", label: "AI Processes Running", color: "pink" },
  { icon: Activity, value: "1,024+", label: "Active Nodes", color: "green" },
];

const services = [
  { icon: Shield, title: "Cyber Security", desc: "Advanced protection for your digital assets and infrastructure.", color: "var(--neon-purple)" },
  { icon: Cloud, title: "Cloud Infrastructure", desc: "Scalable, secure, and reliable cloud solutions for businesses.", color: "var(--neon-cyan)" },
  { icon: Brain, title: "AI Solutions Lab", desc: "Intelligent AI systems to automate and accelerate growth.", color: "var(--neon-pink)" },
  { icon: Code2, title: "Web & App Development", desc: "Futuristic websites, web apps and digital platforms.", color: "var(--neon-cyan)" },
  { icon: Glasses, title: "Immersive Technologies", desc: "AR/VR, metaverse spaces and next-gen experiences.", color: "var(--neon-purple)" },
];

const projects = [
  { icon: Network, title: "Neural Grid", desc: "AI-powered monitoring and analytics system.", tag: "AI System" },
  { icon: Shield, title: "Phantom Shield", desc: "Advanced cybersecurity operations dashboard.", tag: "Cyber Security" },
  { icon: Cloud, title: "Nova Cloud", desc: "Next-gen distributed cloud infrastructure.", tag: "Cloud Platform" },
  { icon: CircuitBoard, title: "Vortex UI", desc: "Immersive futuristic frontend framework.", tag: "Web Technology" },
];

function colorClass(c: string) {
  return {
    purple: "text-[var(--neon-purple)]",
    cyan: "text-[var(--neon-cyan)]",
    pink: "text-[var(--neon-pink)]",
    green: "text-[var(--neon-green)]",
  }[c]!;
}

function Index() {
  return (
    <div className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-40 pointer-events-none" />

      <SiteNav />

      {/* HERO */}
      <section className="relative z-10 px-6 lg:px-10 mt-8">
        <div className="glass-panel rounded-2xl overflow-hidden relative scanline">
          <div className="grid lg:grid-cols-2 gap-0">
            <div className="p-10 lg:p-14 flex flex-col justify-center">
              <h1 className="font-display text-6xl lg:text-8xl font-black tracking-wider neon-text-purple leading-none">
                CYBER<br />SCAPE
              </h1>
              <p className="mt-4 text-sm font-mono uppercase tracking-[0.3em] neon-text-cyan">
                Next Generation Digital Platform
              </p>
              <p className="mt-6 text-muted-foreground max-w-md leading-relaxed">
                We deliver advanced cyber services, cloud infrastructure, AI solutions, and futuristic digital experiences to empower businesses in the new era.
              </p>
              <div className="mt-8 flex flex-wrap gap-4">
                <Link to="/services" className="rounded-lg px-6 py-3 text-xs font-mono uppercase tracking-widest text-primary-foreground flex items-center gap-2 animate-pulse-glow" style={{ background: "var(--gradient-purple)" }}>
                  Explore Services <ArrowRight className="size-4" />
                </Link>
                <Link to="/contact" className="glass-panel glow-border-cyan rounded-lg px-6 py-3 text-xs font-mono uppercase tracking-widest neon-text-cyan">
                  Contact Us
                </Link>
              </div>
            </div>
            <div className="relative min-h-[400px]">
              <img src={heroCity} alt="Neon cyberpunk city" width={1536} height={1024} className="absolute inset-0 w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-l from-transparent via-background/20 to-background/80" />
            </div>
          </div>
        </div>
      </section>

      {/* STATS */}
      <section className="relative z-10 px-6 lg:px-10 mt-6">
        <div className="glass-panel rounded-2xl p-6 grid grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((s) => (
            <div key={s.label} className="flex items-center gap-4">
              <div className="size-12 rounded-lg glass-panel flex items-center justify-center">
                <s.icon className={`size-6 ${colorClass(s.color)}`} />
              </div>
              <div>
                <div className={`font-display text-2xl font-bold ${colorClass(s.color)}`}>{s.value}</div>
                <div className="text-xs font-mono uppercase tracking-wider text-muted-foreground">{s.label}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* SERVICES */}
      <section className="relative z-10 px-6 lg:px-10 mt-6">
        <div className="glass-panel rounded-2xl p-8">
          <div className="flex items-center justify-between mb-8">
            <h2 className="font-display text-xl font-bold tracking-widest text-foreground">OUR CORE SERVICES</h2>
            <a href="#" className="text-xs font-mono uppercase tracking-widest neon-text-pink flex items-center gap-2">
              View all services <ArrowRight className="size-3.5" />
            </a>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-4">
            {services.map((s) => (
              <div key={s.title} className="glass-panel rounded-xl p-5 hover:scale-[1.03] transition-all group cursor-pointer" style={{ borderColor: `${s.color}` }}>
                <div className="size-12 rounded-lg flex items-center justify-center mb-4" style={{ background: `color-mix(in oklab, ${s.color} 15%, transparent)`, boxShadow: `0 0 20px color-mix(in oklab, ${s.color} 30%, transparent)` }}>
                  <s.icon className="size-6" style={{ color: s.color }} />
                </div>
                <h3 className="font-display text-sm font-bold tracking-wider mb-2" style={{ color: s.color }}>
                  {s.title.toUpperCase()}
                </h3>
                <p className="text-xs text-muted-foreground leading-relaxed mb-4">{s.desc}</p>
                <div className="text-xs font-mono uppercase tracking-widest flex items-center gap-1" style={{ color: s.color }}>
                  Explore <ArrowRight className="size-3 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PANELS ROW */}
      <section className="relative z-10 px-6 lg:px-10 mt-6 grid lg:grid-cols-3 gap-6">
        {/* THE CORE */}
        <div className="glass-panel rounded-2xl p-6">
          <div className="flex items-center gap-4 mb-4">
            <div className="size-20 rounded-full flex items-center justify-center animate-pulse-glow" style={{ background: "radial-gradient(circle, var(--neon-purple), oklch(0.13 0.04 280))" }}>
              <Globe2 className="size-10 text-white animate-float" />
            </div>
            <div>
              <h3 className="font-display text-lg font-bold neon-text-purple">THE CORE</h3>
              <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">AI Engine</p>
            </div>
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed mb-4">
            The Core is CyberScape's intelligent digital engine powering security, automation, cloud intelligence, and futuristic innovation across global networks.
          </p>
          <button className="glass-panel glow-border-purple rounded-lg w-full py-2.5 text-xs font-mono uppercase tracking-widest neon-text-purple flex items-center justify-center gap-2">
            Explore the core <ArrowRight className="size-3.5" />
          </button>
        </div>

        {/* LIVE NETWORK */}
        <div className="glass-panel rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display text-sm font-bold tracking-widest neon-text-cyan">LIVE NETWORK STATUS</h3>
            <span className="text-[10px] font-mono uppercase flex items-center gap-1.5 neon-text-green">
              <span className="size-2 rounded-full bg-[var(--neon-green)] animate-pulse" /> Live
            </span>
          </div>
          <div className="relative h-32 rounded-lg glass-panel overflow-hidden mb-4">
            <div className="absolute inset-0 grid-bg opacity-60" />
            {[...Array(24)].map((_, i) => (
              <span
                key={i}
                className="absolute size-1.5 rounded-full bg-[var(--neon-cyan)] animate-pulse"
                style={{
                  left: `${(i * 37) % 95}%`,
                  top: `${(i * 53) % 85}%`,
                  boxShadow: "0 0 8px var(--neon-cyan)",
                  animationDelay: `${i * 0.2}s`,
                }}
              />
            ))}
          </div>
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div>
              <div className="text-muted-foreground font-mono uppercase tracking-wider text-[10px]">Network Stability</div>
              <div className="neon-text-cyan font-display font-bold text-lg">99.8%</div>
              <div className="h-1 rounded-full bg-secondary mt-1 overflow-hidden">
                <div className="h-full w-[99%]" style={{ background: "var(--gradient-neon)" }} />
              </div>
            </div>
            <div>
              <div className="text-muted-foreground font-mono uppercase tracking-wider text-[10px]">Traffic Load</div>
              <div className="neon-text-purple font-display font-bold text-lg">Moderate</div>
              <div className="h-1 rounded-full bg-secondary mt-1 overflow-hidden">
                <div className="h-full w-[60%] bg-[var(--neon-purple)]" />
              </div>
            </div>
          </div>
        </div>

        {/* CYBER ASSISTANT */}
        <div className="glass-panel rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display text-sm font-bold tracking-widest neon-text-pink">CYBER ASSISTANT</h3>
            <span className="text-[10px] font-mono uppercase flex items-center gap-1.5 neon-text-green">
              <span className="size-2 rounded-full bg-[var(--neon-green)] animate-pulse" /> Online
            </span>
          </div>
          <div className="flex gap-3 mb-4">
            <div className="size-14 rounded-xl glass-panel glow-border-purple flex items-center justify-center shrink-0 animate-float">
              <Bot className="size-7 neon-text-purple" />
            </div>
            <div className="text-xs space-y-2 flex-1">
              <p className="neon-text-cyan font-mono">Welcome back, Operator.</p>
              <ul className="space-y-1 text-muted-foreground">
                <li className="flex gap-2"><Radio className="size-3 mt-0.5 neon-text-green" /> 3 security alerts neutralized</li>
                <li className="flex gap-2"><Activity className="size-3 mt-0.5 neon-text-cyan" /> Cloud node stability 99.8%</li>
                <li className="flex gap-2"><Zap className="size-3 mt-0.5 neon-text-pink" /> AI systems operational</li>
              </ul>
            </div>
          </div>
          <button className="glass-panel rounded-lg w-full py-2.5 text-xs font-mono uppercase tracking-widest neon-text-pink flex items-center justify-center gap-2 border border-[var(--neon-pink)]/40">
            Ask me anything <Send className="size-3.5" />
          </button>
        </div>
      </section>

      {/* FEATURED PROJECTS */}
      <section className="relative z-10 px-6 lg:px-10 mt-6 mb-10">
        <div className="glass-panel rounded-2xl p-8">
          <div className="flex items-center justify-between mb-8">
            <h2 className="font-display text-xl font-bold tracking-widest">FEATURED PROJECTS</h2>
            <a href="#" className="text-xs font-mono uppercase tracking-widest neon-text-pink flex items-center gap-2">
              View all projects <ArrowRight className="size-3.5" />
            </a>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {projects.map((p) => (
              <div key={p.title} className="glass-panel rounded-xl p-5 hover:scale-[1.03] transition-all group">
                <div className="h-32 rounded-lg mb-4 flex items-center justify-center relative overflow-hidden" style={{ background: "var(--gradient-card)" }}>
                  <div className="absolute inset-0 grid-bg opacity-40" />
                  <p.icon className="size-16 neon-text-purple animate-float relative z-10" />
                </div>
                <h3 className="font-display font-bold tracking-wider mb-2">{p.title.toUpperCase()}</h3>
                <p className="text-xs text-muted-foreground leading-relaxed mb-4">{p.desc}</p>
                <span className="inline-block text-[10px] font-mono uppercase tracking-widest px-3 py-1 rounded-md glass-panel neon-text-cyan border border-[var(--neon-cyan)]/30">
                  {p.tag}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
