import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { Send, CheckCircle2, Mail, MapPin, Radio } from "lucide-react";
import { SiteNav } from "@/components/cyber/SiteNav";
import { SiteFooter } from "@/components/cyber/SiteFooter";
import { PageHero } from "@/components/cyber/PageHero";

export const Route = createFileRoute("/contact")({
  component: ContactPage,
  head: () => ({
    meta: [
      { title: "Contact — CyberScape" },
      { name: "description", content: "Open a direct channel with CyberScape. Tell us about your mission." },
    ],
  }),
});

const schema = z.object({
  name: z.string().trim().min(2, "Identifier must be at least 2 characters").max(80),
  email: z.string().trim().email("Invalid transmission frequency").max(160),
  subject: z.string().trim().min(3, "Subject required").max(120),
  message: z.string().trim().min(10, "Transmission too short (min 10 chars)").max(2000),
});

type FormState = z.infer<typeof schema>;
type Errors = Partial<Record<keyof FormState, string>>;

function ContactPage() {
  const [form, setForm] = useState<FormState>({ name: "", email: "", subject: "", message: "" });
  const [errors, setErrors] = useState<Errors>({});
  const [status, setStatus] = useState<"idle" | "sending" | "sent">("idle");

  const update = (k: keyof FormState) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm((f) => ({ ...f, [k]: e.target.value }));
    if (errors[k]) setErrors((er) => ({ ...er, [k]: undefined }));
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const result = schema.safeParse(form);
    if (!result.success) {
      const errs: Errors = {};
      for (const issue of result.error.issues) {
        const key = issue.path[0] as keyof FormState;
        if (!errs[key]) errs[key] = issue.message;
      }
      setErrors(errs);
      return;
    }
    setStatus("sending");
    // Simulate transmission
    await new Promise((r) => setTimeout(r, 1200));
    setStatus("sent");
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-40 pointer-events-none" />
      <SiteNav />
      <PageHero
        eyebrow="Open transmission"
        title="CONTACT"
        subtitle="Send a signal. Our operators monitor every frequency 24/7 — expect a response within one orbital cycle."
      />

      <section className="relative z-10 px-6 lg:px-10 mt-6 mb-10 grid lg:grid-cols-3 gap-5">
        {/* CHANNELS */}
        <div className="space-y-5">
          {[
            { icon: Mail, label: "Email channel", value: "operators@cyberscape.io", color: "var(--neon-purple)" },
            { icon: Radio, label: "Frequency", value: "@cyberscape.network", color: "var(--neon-cyan)" },
            { icon: MapPin, label: "Coordinates", value: "Sector 7 / Neo-Tokyo", color: "var(--neon-pink)" },
          ].map((c) => (
            <div key={c.label} className="glass-panel rounded-2xl p-6 flex items-start gap-4" style={{ borderColor: c.color }}>
              <div className="size-12 rounded-lg flex items-center justify-center shrink-0"
                style={{ background: `color-mix(in oklab, ${c.color} 15%, transparent)`, boxShadow: `0 0 20px color-mix(in oklab, ${c.color} 30%, transparent)` }}>
                <c.icon className="size-6" style={{ color: c.color }} />
              </div>
              <div>
                <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">{c.label}</p>
                <p className="font-display font-bold tracking-wider mt-1" style={{ color: c.color }}>{c.value}</p>
              </div>
            </div>
          ))}
        </div>

        {/* FORM */}
        <div className="glass-panel rounded-2xl p-8 lg:col-span-2 relative scanline">
          {status === "sent" ? (
            <div className="flex flex-col items-center justify-center text-center min-h-[400px]">
              <CheckCircle2 className="size-16 neon-text-cyan mb-4 animate-pulse-glow" />
              <h2 className="font-display text-3xl font-bold neon-text-purple tracking-wider">TRANSMISSION RECEIVED</h2>
              <p className="text-sm text-muted-foreground mt-3 max-w-md">
                Signal locked, operator. We've routed your message through the secure channel and an agent will respond shortly.
              </p>
              <button
                onClick={() => { setForm({ name: "", email: "", subject: "", message: "" }); setStatus("idle"); }}
                className="mt-8 glass-panel glow-border-cyan rounded-lg px-6 py-3 text-xs font-mono uppercase tracking-widest neon-text-cyan"
              >
                Send another transmission
              </button>
            </div>
          ) : (
            <form onSubmit={submit} className="space-y-5" noValidate>
              <h2 className="font-display text-xl font-bold tracking-widest neon-text-purple">OPEN CHANNEL</h2>
              <div className="grid sm:grid-cols-2 gap-5">
                <Field label="Operator ID" error={errors.name}>
                  <input value={form.name} onChange={update("name")} className={inputCls(errors.name)} placeholder="Your name" autoComplete="name" />
                </Field>
                <Field label="Frequency" error={errors.email}>
                  <input type="email" value={form.email} onChange={update("email")} className={inputCls(errors.email)} placeholder="you@domain.io" autoComplete="email" />
                </Field>
              </div>
              <Field label="Subject" error={errors.subject}>
                <input value={form.subject} onChange={update("subject")} className={inputCls(errors.subject)} placeholder="Mission briefing" />
              </Field>
              <Field label="Transmission" error={errors.message}>
                <textarea value={form.message} onChange={update("message")} rows={6} className={inputCls(errors.message) + " resize-none"} placeholder="Describe your objective..." />
              </Field>
              <button
                type="submit"
                disabled={status === "sending"}
                className="rounded-lg px-6 py-3.5 text-xs font-mono uppercase tracking-widest text-primary-foreground flex items-center gap-2 animate-pulse-glow disabled:opacity-60"
                style={{ background: "var(--gradient-purple)" }}
              >
                {status === "sending" ? "Transmitting..." : "Send transmission"} <Send className="size-4" />
              </button>
            </form>
          )}
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}

function Field({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">{label}</span>
      <div className="mt-1.5">{children}</div>
      {error && <p className="text-[11px] font-mono mt-1.5 text-destructive">⚠ {error}</p>}
    </label>
  );
}

function inputCls(error?: string) {
  return `w-full bg-background/40 border rounded-lg px-4 py-3 text-sm font-mono text-foreground placeholder:text-muted-foreground/50 outline-none transition-all focus:border-[var(--neon-cyan)] focus:shadow-[0_0_20px_oklch(0.85_0.18_195/0.3)] ${
    error ? "border-destructive" : "border-border"
  }`;
}
